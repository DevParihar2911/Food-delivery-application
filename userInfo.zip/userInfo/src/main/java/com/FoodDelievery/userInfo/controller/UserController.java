package com.FoodDelievery.userInfo.controller;

import org.springframework.http.HttpStatus;
import com.FoodDelievery.userInfo.dto.UserDTO;
import org.springframework.http.ResponseEntity;
import com.FoodDelievery.userInfo.service.UserService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	@PostMapping("/addUser")
	public ResponseEntity<UserDTO> addUser(@RequestBody UserDTO userDTO) {
		UserDTO savedUserDTO = userService.addUser(userDTO);
		return new ResponseEntity<>(savedUserDTO, HttpStatus.CREATED);
	}
	
	@GetMapping("/fetchUserById/{userId}")
	public ResponseEntity<UserDTO> fetchUserDetailsById(@PathVariable Integer userId) {
		ResponseEntity<UserDTO> fetchedUser = userService.fetchUserDetailsById(userId);
		return fetchedUser;
	}
	
	@GetMapping("/fetchAllUsers")
	public ResponseEntity<List<UserDTO>> fetchAllUsers() {
		ResponseEntity<List<UserDTO>> fetchedUser = userService.fetchAllUsers();
		return fetchedUser;
	}
}