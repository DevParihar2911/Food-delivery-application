package com.FoodDelievery.userInfo.service;

import org.springframework.stereotype.Service;
import com.FoodDelievery.userInfo.dto.UserDTO;
import com.FoodDelievery.userInfo.entity.User;
import com.FoodDelievery.userInfo.mapper.UserMapper;
import com.FoodDelievery.userInfo.repo.UserRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public UserDTO addUser(UserDTO userDTO) {
		User savedUser = userRepository.save(modelMapper.map(userDTO, User.class));
		UserDTO savedUserDTO = modelMapper.map(savedUser, UserDTO.class);
		
		return savedUserDTO;
	}

	public ResponseEntity<UserDTO> fetchUserDetailsById(Integer userId) {
		Optional<User> fetchedUser = userRepository.findById(userId);
		if(fetchedUser.isPresent()) {
			return new ResponseEntity<>(modelMapper.map(fetchedUser.get(), UserDTO.class), HttpStatus.OK);
		}
		
		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	}

	public ResponseEntity<List<UserDTO>> fetchAllUsers() {
		List<User> fetchedUsers = userRepository.findAll();
		if(fetchedUsers.isEmpty()) {
			return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
		}
		
		List<UserDTO> fetchedUserDTO = fetchedUsers.stream().map(user -> modelMapper.map(user, UserDTO.class)).collect(Collectors.toList());
		return new ResponseEntity<>(fetchedUserDTO, HttpStatus.OK);
	}
}
