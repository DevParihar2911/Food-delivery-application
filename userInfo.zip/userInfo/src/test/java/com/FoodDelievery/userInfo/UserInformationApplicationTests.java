package com.FoodDelievery.userInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserInformationApplicationTests {

	@Test
	void contextLoads() {
	}

}
