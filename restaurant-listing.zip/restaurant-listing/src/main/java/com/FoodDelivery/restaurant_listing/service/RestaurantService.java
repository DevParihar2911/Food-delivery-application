package com.FoodDelivery.restaurant_listing.service;

import java.util.*;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import com.FoodDelivery.restaurant_listing.dto.RestaurantDTO;
import com.FoodDelivery.restaurant_listing.entity.Restaurant;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.FoodDelivery.restaurant_listing.repo.RestaurantRepo;
import com.FoodDelivery.restaurant_listing.mapper.RestaurantMapper;

@Service
public class RestaurantService {
	@Autowired
	RestaurantRepo restaurantRepo;
	
	@Autowired
	private ModelMapper modelMapper;

	public List<RestaurantDTO> findAllRestaurants() {
		List<Restaurant> allRestaurants = restaurantRepo.findAll();
		
		//Map it to list of DTO's
		List<RestaurantDTO> restaurantDTOList = allRestaurants.stream().map(restaurant -> modelMapper.map(restaurant, RestaurantDTO.class)).collect(Collectors.toList());
		return restaurantDTOList;
	}

	public RestaurantDTO addRestaurantInDB(RestaurantDTO restaurantDTO) {
		Restaurant savedRestaurant = restaurantRepo.save(modelMapper.map(restaurantDTO, Restaurant.class));
		return modelMapper.map(savedRestaurant, RestaurantDTO.class);
	}
	
	public ResponseEntity<RestaurantDTO> fetchRestaurantById(Integer id) {
		Optional<Restaurant> restaurant = restaurantRepo.findById(id);
		if(restaurant.isPresent()) 
			return new ResponseEntity<>(modelMapper.map(restaurant.get(), RestaurantDTO.class), HttpStatus.OK);
		
		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	}
}