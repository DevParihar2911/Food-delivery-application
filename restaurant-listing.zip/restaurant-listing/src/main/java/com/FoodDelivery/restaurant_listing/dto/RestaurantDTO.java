package com.FoodDelivery.restaurant_listing.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RestaurantDTO {
	private int id;
	private String name;
	private String city;
	private String address;
	private String restaurantDescription;
}
