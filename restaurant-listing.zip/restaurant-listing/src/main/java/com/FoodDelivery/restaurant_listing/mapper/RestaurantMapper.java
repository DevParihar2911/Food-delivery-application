package com.FoodDelivery.restaurant_listing.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.FoodDelivery.restaurant_listing.dto.RestaurantDTO;
import com.FoodDelivery.restaurant_listing.entity.Restaurant;

@Mapper
public interface RestaurantMapper {
	RestaurantMapper INSTANCE = Mappers.getMapper(RestaurantMapper.class);
	
	RestaurantDTO mapRestaurantToRestaurantDTO(Restaurant restaurant);
	Restaurant mapRestaurantDTOToRestaurant(RestaurantDTO restaurantDTO);
}