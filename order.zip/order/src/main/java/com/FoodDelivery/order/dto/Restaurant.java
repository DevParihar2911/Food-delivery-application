package com.FoodDelivery.order.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Restaurant {
	private int id;
	private String name;
	private String city;
	private String address;
	private String restaurantDescription;
}
