package com.FoodDelivery.order.repo;

import com.FoodDelivery.order.entity.Order;
import org.springframework.stereotype.Repository;
import org.springframework.data.mongodb.repository.MongoRepository;

@Repository
public interface OrderRepo extends MongoRepository<Order, Integer>{

}
