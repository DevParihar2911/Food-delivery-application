package com.FoodDelivery.order.service;

import org.modelmapper.ModelMapper;
import com.FoodDelivery.order.dto.UserDTO;
import com.FoodDelivery.order.dto.OrderDTO;
import com.FoodDelivery.order.entity.Order;
import com.FoodDelivery.order.repo.OrderRepo;
import org.springframework.stereotype.Service;
import com.FoodDelivery.order.dto.OrderDTOFromFE;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class OrderService {
	@Autowired
	private SequenceGenerator sequenceGenerator;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private OrderRepo orderRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public OrderDTO saveOrderInDb(OrderDTOFromFE orderDetails) {
		//1. Get new order id
		Integer newOrderId = sequenceGenerator.generateNextOrderId();
		
		//2. Get UserDTO 
		UserDTO userDTO = fetchUserDetailsFromUserId(orderDetails.getUserId());
		
		Order orderToBeSaved = new Order(newOrderId, orderDetails.getFoodItemsList(), orderDetails.getRestaurant(), userDTO);
		Order savedOrder = orderRepo.save(orderToBeSaved);
		
		return modelMapper.map(savedOrder, OrderDTO.class);
	}

	private UserDTO fetchUserDetailsFromUserId(Integer userId) {
		return restTemplate.getForObject("http://USERINFORMATION/user/fetchUserById/" + userId, UserDTO.class);
	}
}
