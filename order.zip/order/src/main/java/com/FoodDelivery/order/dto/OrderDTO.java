package com.FoodDelivery.order.dto;

import lombok.Data;
import java.util.List;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderDTO {
	private Integer orderId;
	private List<FoodItemsDTO> foodItemsDTO;
	private Restaurant restaurant;
	private UserDTO userDTO;
}
