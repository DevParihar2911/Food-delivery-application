package com.FoodDelivery.order.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.FoodDelivery.order.dto.OrderDTO;
import com.FoodDelivery.order.entity.Order;

@Mapper
public interface OrderMapper {
	OrderMapper INSTANCE = Mappers.getMapper(OrderMapper.class);
	
	Order mapOrderDTOToOrder(OrderDTO orderDto);
	OrderDTO mapOrderToOrderDTO(Order order);
}