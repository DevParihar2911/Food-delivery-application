package com.FoodDelivery.order.entity;

import lombok.Data;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.FoodDelivery.order.dto.UserDTO;
import com.FoodDelivery.order.dto.Restaurant;
import com.FoodDelivery.order.dto.FoodItemsDTO;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document("order")
public class Order {
	private Integer orderId;
	private List<FoodItemsDTO> foodItemsDTO;
	private Restaurant restaurant;
	private UserDTO userDTO;
}