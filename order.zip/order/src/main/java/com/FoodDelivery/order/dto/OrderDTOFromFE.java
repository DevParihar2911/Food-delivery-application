package com.FoodDelivery.order.dto;

import lombok.Data;
import java.util.List;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderDTOFromFE {
	private List<FoodItemsDTO> foodItemsList;
	private Integer userId;
	private Restaurant restaurant;
}