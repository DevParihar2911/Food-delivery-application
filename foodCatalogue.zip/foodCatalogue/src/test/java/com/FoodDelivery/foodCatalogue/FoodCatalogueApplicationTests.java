package com.FoodDelivery.foodCatalogue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodCatalogueApplicationTests {

	@Test
	void contextLoads() {
	}

}
