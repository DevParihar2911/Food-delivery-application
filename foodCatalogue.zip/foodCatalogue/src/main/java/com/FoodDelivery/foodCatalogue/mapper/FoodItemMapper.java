package com.FoodDelivery.foodCatalogue.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.FoodDelivery.foodCatalogue.dto.FoodItemDTO;
import com.FoodDelivery.foodCatalogue.entity.FoodItem;

@Mapper
public interface FoodItemMapper {
	FoodItemMapper INSTANCE = Mappers.getMapper(FoodItemMapper.class);
	
	FoodItemDTO mapFoodItemToFoodItemDTO(FoodItem foodItem);
	FoodItem mapFoodItemDTOToFoodItem(FoodItemDTO foodItemDTO);
}