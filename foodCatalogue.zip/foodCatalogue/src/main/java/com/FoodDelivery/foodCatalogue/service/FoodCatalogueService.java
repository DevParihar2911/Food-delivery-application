package com.FoodDelivery.foodCatalogue.service;

import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.FoodDelivery.foodCatalogue.dto.Restaurant;
import com.FoodDelivery.foodCatalogue.dto.FoodItemDTO;
import com.FoodDelivery.foodCatalogue.entity.FoodItem;
import com.FoodDelivery.foodCatalogue.repo.FoodItemRepo;
import com.FoodDelivery.foodCatalogue.dto.FoodCataloguePage;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class FoodCatalogueService {
	@Autowired
	FoodItemRepo foodItemRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private RestTemplate restTemplate;

	public FoodItemDTO addFoodItem(FoodItemDTO foodItemDto) {
		FoodItem savedFoodItem = foodItemRepo.save(modelMapper.map(foodItemDto, FoodItem.class));
		return modelMapper.map(savedFoodItem, FoodItemDTO.class);
	}

	public FoodCataloguePage fetchFoodCataloguePageDetails(Integer restaurantId) {
		//1. Fetch Food Item List
		List<FoodItem> foodItemList = fetchFoodItemList(restaurantId);
		
		//2. Fetch Restaurant Details
		Restaurant restaurant = fetchRestaurantDetailsFromRestaurantMS(restaurantId);
		
		//3. Create Food Catalogue Page
		FoodCataloguePage foodCataloguePage = createFoodCataloguePage(foodItemList, restaurant);
		
		return foodCataloguePage;
	}

	private FoodCataloguePage createFoodCataloguePage(List<FoodItem> foodItemList, Restaurant restaurant) {
		FoodCataloguePage foodCataloguePage = new FoodCataloguePage();
		foodCataloguePage.setFoodItemsList(foodItemList);
		foodCataloguePage.setRestaurant(restaurant);
		
		return foodCataloguePage;
	}

	private Restaurant fetchRestaurantDetailsFromRestaurantMS(Integer restaurantId) {
		return restTemplate.getForObject("http://Restaurant-Service/restaurant/fetchById/" + restaurantId, Restaurant.class);
	}

	private List<FoodItem> fetchFoodItemList(Integer restaurantId) {
		return foodItemRepo.findByRestaurantId(restaurantId);
	}
}
