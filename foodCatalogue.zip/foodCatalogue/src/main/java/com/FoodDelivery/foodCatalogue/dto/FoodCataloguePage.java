package com.FoodDelivery.foodCatalogue.dto;

import lombok.Data;
import java.util.List;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.FoodDelivery.foodCatalogue.entity.FoodItem;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FoodCataloguePage {
	private List<FoodItem> foodItemsList;
	private Restaurant restaurant;
}
